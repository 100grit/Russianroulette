﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Media;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using RussianRoulette.Properties;

namespace RussianRoulette
{
 
    public partial class Form1 : Form
    {
        private long size;
        private long highScore;
        public bool folder;
        public bool file;
        public Random rnd = new Random();
       public int blanks =0;
        public int dealerlive = 2;
        public int lives =0;
        public string filename;
        public string foldername;
       public bool? response;
        public string [] filesarray;
        public string files;
        public Form1()
        {
            InitializeComponent();
            label11.Text = Settings.Default.HighScore.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
            response = openFileDialog.ShowDialog();
            if(response == true)
            {
                file = true;
                filename = openFileDialog.FileName;
                label2.Text = filename;
                blanks = rnd.Next(1, 4);
                lives = Math.Abs(blanks - 6);
                label3.Text = ("Amount of Blanks:" + blanks);
                label4.Text = ("Amount of Bullets:" + lives);
                label7.Text = "";
                dealerlive = 2;
            }
        }

        public void button2_Click(object sender, EventArgs e)
        {
            if (rnd.Next(1, 6) > blanks)
            {
               
                
                if (file)
                {

                    File.Delete(filename);

                }
                else if (folder)
                {
                    Directory.Delete(files, true);


                }
                
                label5.Text = ("It was a Bullet, File Deleted.");
                label2.Text = ("file deleted.");
                label3.Text = ("Amount of Blanks Will be Shown here");
                label4.Text = ("Amount of Bullets will be shown here");

            }
            else
            {
                blanks = blanks - 1; 
                label3.Text = ("Amount of Blanks:" + blanks);
                label5.Text = ("It was a blank, File Okay.");


            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void button3_Click(object sender, EventArgs e)
        {
            if (rnd.Next(1, 6) > blanks)
            {
                dealerlive = dealerlive - 1;
                lives = lives - 1;
                label5.Text = ("It was a Bullet, Dealer was Shot. Your Turn.");
                label4.Text = ("Amount of Bullets:" + lives);
                label6.Text = ("DealersLives :" + dealerlive);

               
                if(dealerlive == 0)
                {

                    label7.Text = "You won!";
                    if(folder)
                    {
                        DirectoryInfo dirInfo = new DirectoryInfo(@files);
                        long dirsize = await Task.Run(() => dirInfo.EnumerateFiles("*", SearchOption.AllDirectories).Sum(file => file.Length));
                        highScore = dirsize;

                        label9.Text = highScore.ToString();
                        if (highScore > Settings.Default.HighScore)
                        {
                            Settings.Default.HighScore = highScore;
                            Settings.Default.Save();
                            label11.ToString();

                        }


                    }
                    if(file)
                    {

                        FileInfo fi = new FileInfo(filename);
                        highScore = fi.Length;
                        label9.Text = highScore.ToString();
                        if(highScore > Settings.Default.HighScore)
                        {
                            Settings.Default.HighScore = highScore;
                            Settings.Default.Save();
                            label11.ToString();


                        }
                    }
                }
            }
            else
            {
                blanks = blanks - 1;
                label3.Text = ("Amount of Blanks:" + blanks);
                label5.Text = ("It was a blank, dealers turn.");
                Thread.Sleep(3750);
                if (rnd.Next(1, 6) > blanks)
                {

                    
                    if (file)
                    {

                        File.Delete(filename);

                    }
                    else if (folder)
                    {
                        Directory.Delete(files, true);


                    }
                    label5.Text = ("dealer shot you, it was a Bullet, File Deleted.");
                    label2.Text = ("file deleted.");
                    label3.Text = ("Amount of Blanks Will be Shown here");
                    label4.Text = ("Amount of Bullets will be shown here");

                   
                }
                else
                {

                    blanks = blanks - 1;
                    label3.Text = ("Amount of Blanks:" + blanks);
                    label5.Text = ("Dealer shot, It was a blank, File Okay. Your Turn.");


                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            Random rnd = new Random();
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();
                
                if (result == DialogResult.OK)
                {
                    response = true;

                    files = fbd.SelectedPath;

                    folder = true;

                }
            }
            
            if (response == true)
            {
                foldername = files.ToString();
                label2.Text = files;
                blanks = rnd.Next(1, 6);
                lives = Math.Abs(blanks - 6);
                label3.Text = ("Amount of Blanks:" + blanks);
                label4.Text = ("Amount of Bullets:" + lives);
                label7.Text = "";
                dealerlive = 2;
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
